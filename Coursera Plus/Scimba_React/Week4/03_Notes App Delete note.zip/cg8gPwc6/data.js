export const data = [
    {
        id: 1,
        body: `### This just in!

Markdown is an *awesome* way to write **very basic HTML** by typing manually

It can be used for:

1. README files
1. Slack and Discord messages
1. **So much more!**

---

Here's a division 👆`,
    },
    { id: 2, body: `a` },
    { id: 3, body: `b` },
    { id: 4, body: `c` },
    { id: 5, body: `d` },
    { id: 6, body: `e` },
]
