# DjangoBooks

List of books(PDF):

1. Django-Admin-CookBook
2. Django API Book
3. Django-ORM-Book
4. Notes-fo-Django-Beginners
5. Python Web Development With Django
6. The Django Book
7. Django Design Patterns
8. Django By Example
9. Mastering Django Core
10. Django - The Easy Way
11. Practical Django 2 & Channels 2
12. Tango With Django
