from django.shortcuts import render
from rest_framework import generics
from django.shortcuts import get_object_or_404
from datetime import date

from .models import MenuItem, Category, Cart, Order, OrderItem

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import permission_classes
from rest_framework.permissions import IsAuthenticated
#from rest_framework.permissions import IsAdminUser
from django.contrib.auth.models import User, Group
from rest_framework import viewsets
from rest_framework.views import APIView

from .serializers import MenuItemSerializer, CategoryMenuSerializer
from .serializers import UserSerializer
from .serializers import OrderItemSerializer
from .serializers import OrderSerializer

# from .serializers import  CartSerializer
from .serializers import CartSerializerView
from .permissions import MenuItemPermission
from .permissions import SingleMenuItemPermission
from .permissions import ManagerGroupPermissions
from .permissions import CartItemsPermissions

# Create your views here.


class CategorItemsView(generics.ListCreateAPIView):
     queryset = Category.objects.all()
     serializer_class = CategoryMenuSerializer


class MenuItemViews(generics.ListCreateAPIView):
    queryset = MenuItem.objects.select_related('category').all()
    serializer_class = MenuItemSerializer
    permission_classes = [MenuItemPermission]


class SingleMenuItemsView(generics.RetrieveUpdateAPIView, generics.DestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [SingleMenuItemPermission]


class ManagerUsersView(generics.ListCreateAPIView):
    queryset = User.objects.filter(groups__name='Manager')
    serializer_class = UserSerializer
    permission_classes = [ManagerGroupPermissions]

class SingleManagerUsersView(generics.RetrieveUpdateAPIView, generics.DestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [SingleMenuItemPermission]


class DeliveryCrewView(generics.ListCreateAPIView):
    queryset = User.objects.filter(groups__name='Delivery')
    serializer_class = UserSerializer
    permission_classes = [ManagerGroupPermissions]

class SingleDeliveryCrewView(generics.RetrieveUpdateAPIView, generics.DestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [SingleMenuItemPermission]




@api_view(['GET', 'POST', 'DELETE'])
@permission_classes([ManagerGroupPermissions])
def add_to_managers(request):
    username = request.data["username"]
    if username:
        user = get_object_or_404(User, username=username)
        managers = Group.objects.get(name="Manager")
        if request.method == 'POST':
            managers.user_set.add(user)
            message = "User {} added to Manager group.".format(username)
            res_status = status.HTTP_201_CREATED
        if request.method == 'DELETE':
            managers.user_set.remove(user)
            message = "User {} removed from Manager group.".format(username)
            res_status = status.HTTP_200_OK
        return Response({"message":message}, status=res_status) 
    return Response({"message":"error"}, status=status.HTTP_400_BAD_REQUEST)


# class CartViewSet(viewsets.ModelViewSet):
#     queryset = Cart.objects.all()
#     serializer_class = CartSerializer

#     def list(self, request):
#         queryset = Cart.objects.filter(user=request.user)
#         serializer = CartSerializer(queryset, many=True)
#         return Response(serializer.data)

#     def create(self, request):
#         data = request.data
#         menu_item = MenuItem.objects.get(id=data.get('menu_item_id'))
#         cart_item, created = Cart.objects.get_or_create(user=request.user, menuitem=menu_item)
#         if not created:
#             cart_item.quantity += int(data.get('quantity', 1))
#         cart_item.save()
#         serializer = CartSerializer(cart_item)
#         return Response(serializer.data)

#     def destroy(self, request, pk=None):
#         Cart.objects.filter(user=request.user).delete()
#         return Response(status=204)
    


class CartView(APIView):
    permission_classes = [CartItemsPermissions]

    def post(self, request, format=None):
        menu_item_id = request.data.get('menuitem')
        quantity = int(request.data.get('quantity'))
        menu_item = get_object_or_404(MenuItem, pk=menu_item_id)
        unit_price = menu_item.price
        price = quantity * unit_price
        cart_item = Cart.objects.create(
            user=request.user,
            menuitem=menu_item,
            quantity=quantity,
            unit_price=unit_price,
            price=price
        )
        serializer = CartSerializerView(cart_item)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    def get(self, request, format=None):
        cart_items = Cart.objects.filter(user=request.user)
        serializer = CartSerializerView(cart_items, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def delete(self, request, format=None):
        Cart.objects.filter(user=request.user).delete()
        return Response(status=status.HTTP_200_OK)
    


class OrdersView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):
            if request.user.groups.filter(name='Customer').exists():
                orders = Order.objects.filter(user=request.user)
            elif request.user.groups.filter(name='Manager').exists():
                orders = Order.objects.all()
            elif request.user.groups.filter(name='Delivery').exists():
                orders = Order.objects.filter(delivery_crew=request.user)
            elif request.user.is_superuser:
                orders = Order.objects.all()
            else:
                return Response({"detail": "You do not have permission to perform this action."}, status=status.HTTP_403_FORBIDDEN)
            serializer = OrderSerializer(orders, many=True)
            return Response(serializer.data)
    
    def post(self, request):
        if request.user.groups.filter(name='Customer').exists():
            cart_items = Cart.objects.filter(user=request.user)
            if cart_items.exists():
                order = Order.objects.create(user=request.user, total=sum(item.price for item in cart_items), date=date.today())
                for item in cart_items:
                    OrderItem.objects.create(order=order, menuitem=item.menuitem, quantity=item.quantity, unit_price=item.unit_price, price=item.price)
                cart_items.delete()
                serializer = OrderSerializer(order)
                return Response(serializer.data, status=201)
            else:
                return Response({"detail": "No items in cart to create an order."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "You do not have permission to perform this action."}, status=status.HTTP_403_FORBIDDEN)
        


class OrderItemView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return OrderItem.objects.get(pk=pk)
        except OrderItem.DoesNotExist:
            return Response({"error": "OrderItem with id {} does not exist".format(pk)}, status=status.HTTP_404_NOT_FOUND)

    def get(self, request, pk, format=None):
        order_item = self.get_object(pk)
        if isinstance(order_item, Response):
            return order_item
        
        if request.user.groups.filter(name='Customer').exists() and order_item.order.user == request.user:
            serializer = OrderItemSerializer(order_item)
            return Response(serializer.data)
        else:
            return Response({"detail": "You do not have permission to perform this action."}, status=403)

    def put(self, request, pk, format=None):
        order_item = self.get_object(pk)
        if isinstance(order_item, Response):
            return order_item
        if request.user.groups.filter(name='Customer').exists() and order_item.order.user == request.user:
            serializer = OrderItemSerializer(order_item, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=400)
        else:
            return Response({"detail": "You do not have permission to perform this action."}, status=403)

    def delete(self, request, pk, format=None):
        order_item = self.get_object(pk)
        if isinstance(order_item, Response):
            return order_item
        if request.user.groups.filter(name='Manager').exists():
            order_item.delete()
            return Response(status=204)
        else:
            return Response({"detail": "You do not have permission to perform this action."}, status=403)

    def patch(self, request, pk, format=None):
        order_item = self.get_object(pk)
        if isinstance(order_item, Response):
            return order_item
        if request.user.groups.filter(name='Delivery').exists() and order_item.order.delivery_crew == request.user:
            serializer = OrderItemSerializer(order_item, data=request.data, partial=True) # set partial=True to update a data partially
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=400)
        else:
            return Response({"detail": "You do not have permission to perform this action."}, status=403)
